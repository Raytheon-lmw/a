dpkg -i openssh-server_1%3a7.6p1-4ubuntu0.3_amd64.deb
